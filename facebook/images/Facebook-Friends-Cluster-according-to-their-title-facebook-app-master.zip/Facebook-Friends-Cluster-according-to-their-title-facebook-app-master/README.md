APP Name : Friends Cluster

Description:this app will display clusters of friends according to their designation/Title. it may be  possible your one friend shows in tow differen cluster becuase he worked with different designation in different company.

Developer : Gyaneshwar Pardhi (gyaan)

